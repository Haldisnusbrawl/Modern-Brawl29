from ByteStream.Writer import Writer
from DataBase.DBManager import DB

class BattleEndMessage(Writer):

    def __init__(self, client, player, type, result, players, db: DB):
        super().__init__(client)
        self.id = 23456
        self.player  = player
        self.type    = type
        self.result  = result
        self.players = players
        self.db = db

    def encode(self):
        self.writeVInt(self.type)
        self.writeVInt(self.result)
        trophies = 8
        trpp = 8 + self.player.Ayt
        tokens = 30
        self.writeVInt(tokens)#токены
        self.writeVInt(trpp)#трофеи

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)

        self.writeVInt(self.player.Ayt)#аутсайдер
        self.writeVInt(16)
        self.writeVInt(-64)
        self.writeVInt(1)

        self.writeVInt(len(self.players))

        for player in self.players:
            self.brawler  = self.players[player]['Brawler']
            self.skin     = self.players[player]['Skin']
            self.team     = self.players[player]['Team']
            self.username = self.players[player]['Name']

            if self.type == 5:
                self.writeVInt(player) if self.team == 0 else self.writeVInt(2)
            else:
                self.writeVInt(2 if self.team != 0 else 1) if self.type == 2 else self.writeVInt(self.team if self.team != 1 else 2)

            # 5 - player,
            self.writeDataReference(16, self.brawler)if self.brawler != -1 else self.writeVInt(0)
            self.writeDataReference(29, self.skin)   if self.skin != -1 else self.writeVInt(0)

            self.writeVInt(99999)
            self.writeVInt(99999)
            self.writeVInt(10)

            self.writeBool(False)

            # sub_64DF74
            self.writeString(self.username)
            self.writeVInt(100)
            self.writeVInt(28000000)
            self.writeVInt(43000000)
            self.writeNullVInt()

        # Experience Array
        self.writeVInt(2) # Count
        self.writeVInt(0) # Normal Experience ID
        self.writeVInt(1) # Normal Experience Ammount
        self.writeVInt(8) # Star Player Experience ID
        self.writeVInt(2) # Star Player Experience Ammount

        # Rank Up and Level Up Bonus Array
        self.writeVInt(0) # Count
        #self.writeVInt(39) #  CsvID
        #self.writeVInt(33) # ранг (например 1ранг = 3)
        #self.writeVInt(39) #  CsvID
        #self.writeVInt(34) # ранг 2?


        # Trophies and Experience Bars Array
        self.writeVInt(2) # Count
        self.writeVInt(1) # Ranks Milestone ID
        self.writeVInt(self.player.brawlers_high_trophies[str(self.player.home_brawler)]) # Brawler Trophies Bar
        self.writeVInt(self.player.brawlers_high_trophies[str(self.player.home_brawler)]) # Brawler Trophies for Rank
        self.writeVInt(5) # Experience Milestone ID
        self.writeVInt(0) # Total Experience Bar
        self.writeVInt(0) # ???

        self.writeDataReference(28, 0)

        self.writeBool(False)
        
        self.player.trp = trophies + self.player.Ayt
        self.player.tkn = tokens
        self.player.tokeni += tokens
        
        self.player.trophies += trophies + self.player.Ayt
        self.player.high_trophies += trophies + self.player.Ayt
        self.player.brawlers_trophies[str(self.player.home_brawler)] += trophies + self.player.Ayt
        self.player.brawlers_high_trophies[str(self.player.home_brawler)] += trophies + self.player.Ayt
        self.db.update_player_account(self.player.token, 'Trophies',  self.player.trophies)
        self.db.update_player_account(self.player.token, 'Tokens', self.player.tokeni)
        self.db.update_player_account(self.player.token, 'HighestTrophies',  self.player.high_trophies)
        self.db.update_player_account(self.player.token, 'BrawlersTrophies',  self.player.brawlers_trophies)
        self.db.update_player_account(self.player.token, 'BrawlersHighestTrophies',  self.player.brawlers_high_trophies)